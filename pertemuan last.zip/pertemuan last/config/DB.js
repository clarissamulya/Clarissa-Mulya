const mysql = require('mysql'); // Perbaiki 'conts' menjadi 'const'

const koneksi = mysql.createConnection({ // Perbaiki 'conts' menjadi 'const'
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'latihanrestapi'
});

koneksi.connect((err) => {
    if (err) throw err;
    console.log('MySQL connected...');
});

module.exports = koneksi;