const express = require('express');
const bodyParser = require('body-parser');
const konseksi = require('./config/DB');
const app = express();
const PORT = process.env.PORT || 3000;

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false}));

app.post('/api/latihanrestapi', (req, res) => {

    const data = {...req.body };
    const querySql = 'INSERT INTO latihanrestapi SET ?';

    konseksi.query(querySql, data, (err, rows, field) =>{

        if (err) {
            return res.status(500).json({ message: 'gagal insert data!', error: err });
        }
    res.status(201).json({ succes: true, message: 'berhasil insert data!'  });

    });

});


app.listen(PORT, () => console.log('Server Runinng at Port: $(PORT)'));
